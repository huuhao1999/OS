<?php

namespace FSPoster\App\Pages\Dashboard\Controllers;

trait Ajax
{
}